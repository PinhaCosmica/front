from flask import Blueprint, request, jsonify
from .models import Mascota
from . import db

bp = Blueprint('routes', __name__)

@bp.route('/mascotas', methods=['POST'])
def registrar_mascota():
    data = request.json
    nueva = Mascota(nombre=data['nombre'], duenio=data['duenio'])
    db.session.add(nueva)
    db.session.commit()
    return jsonify({"mensaje": "Mascota registrada"}), 201

@bp.route('/mascotas', methods=['GET'])
def listar_mascotas():
    mascotas = Mascota.query.all()
    return jsonify([m.as_dict() for m in mascotas])
