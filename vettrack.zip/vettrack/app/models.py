from . import db

class Mascota(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), nullable=False)
    duenio = db.Column(db.String(50), nullable=False)

    def as_dict(self):
        return {"id": self.id, "nombre": self.nombre, "duenio": self.duenio}
