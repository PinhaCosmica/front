# VetTrack - Sistema de Registro de Mascotas

## 🛠️ Despliegue

1. Crear base de datos en EC2-DB con PostgreSQL:
   - DB: vettrack
   - Usuario: vetuser
   - Contraseña: vetpass

2. Exportar variable de entorno en EC2-App:
   ```bash
   export DATABASE_URL=postgresql://vetuser:vetpass@<IP_PRIVADA_DB>:5432/vettrack
   ```

3. Instalar dependencias y ejecutar:
   ```bash
   pip install -r requirements.txt
   python run.py
   ```

## 🐾 Endpoints

- `POST /mascotas`
- `GET /mascotas`

## Arquitectura

- Capa de presentación: API REST (Flask)
- Capa de aplicación: lógica en `routes.py`
- Capa de datos: PostgreSQL en instancia separada
